// 本卡 stat_data v3。纯 schema 工厂；不访问聊天、不自动迁移旧楼层。
export const CHAPTERS = ['待选择', '序章', '第一章', '第二章', '第三章', '第四章', '终章'];
export const GRADES = ['A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'E+', 'E', 'F+', 'F'];
export const AXES = ['攻击力', '防御力', '魔力量', '魔力控制', '体能', '运气'];
// 本卡关系计分配置；并非《火焰纹章》任一作品的官方公式。终端构建读取同一份配置。
export const RELATIONSHIP_SCORING = {
  version: 'R06-关系第二版',
  affection: { min: 0, max: 1000, initial: 50, ordinaryMax: 2, majorMax: 5 },
  support: {
    min: 0, max: 320, initial: 0, ordinaryMin: 1, ordinaryMax: 5, mediumMin: 6, mediumMax: 10, majorMin: 10, majorMax: 15,
    stages: [{ stage: 'C', min: 80 }, { stage: 'B', min: 160 }, { stage: 'A', min: 240 }, { stage: 'S', min: 320 }],
  },
  romance: {
    stages: [{ stage: '路人', min: 0 }, { stage: '在意', min: 200 }, { stage: '暧昧', min: 500 }, { stage: '交往', min: 800 }, { stage: '生死相随', min: 1000 }],
  },
};
export function supportStage(value) {
  const config = RELATIONSHIP_SCORING.support;
  if (!Number.isInteger(value) || value < config.min || value > config.max) return '未定';
  let stage = '未建立';
  for (const threshold of config.stages) if (value >= threshold.min) stage = threshold.stage;
  return stage;
}
export function romanceStage(relation) {
  const value = relation?.好感, config = RELATIONSHIP_SCORING.affection;
  if (relation?.性别 !== '女性' || typeof value !== 'number' || !Number.isFinite(value) || value < config.min || value > config.max) return null;
  let stage = null;
  for (const threshold of RELATIONSHIP_SCORING.romance.stages) if (value >= threshold.min) stage = threshold.stage;
  return stage;
}

// 每次 MVU 更新结束只检查每个人的计分字段，不恢复整个人际集合。
// 上限按整轮前后差计算；不能靠拆成多条 JSONPatch 绕过。事件是否真实仍由本局依据判断。
export function enforceRelationshipScores(variables, previous) {
  const before = previous?.stat_data?.人际 || {};
  const after = variables?.stat_data?.人际;
  const notices = [];
  if (!after || typeof after !== 'object' || Array.isArray(after)) return notices;
  for (const [name, relation] of Object.entries(after)) {
    if (!relation || typeof relation !== 'object' || Array.isArray(relation)) continue;
    const old = before[name];
    const evidence = typeof relation.变化依据 === 'string' ? relation.变化依据.trim() : '';
    const repeated = !!evidence && typeof old?.变化依据 === 'string' && evidence === old.变化依据.trim();
    let breakthrough = typeof relation.好感突破依据 === 'string' ? relation.好感突破依据.trim() : '';
    const priorBreakthrough = typeof old?.好感突破依据 === 'string' ? old.好感突破依据.trim() : '';
    let freshBreakthrough = !!breakthrough && breakthrough !== priorBreakthrough;
    if (!freshBreakthrough && evidence && !repeated) {
      const isNew = !old;
      const hasBreakthroughIntent = /突破|核定|基准|特殊开局|既定/.test(evidence);
      if (isNew || hasBreakthroughIntent) {
        const priorAffection = old?.好感;
        const baseline = typeof priorAffection === 'number' && Number.isFinite(priorAffection) ? priorAffection : RELATIONSHIP_SCORING.affection.initial;
        if (typeof relation.好感 === 'number' && Number.isFinite(relation.好感) && Math.abs(relation.好感 - baseline) > RELATIONSHIP_SCORING.affection.majorMax) {
          breakthrough = evidence;
          relation.好感突破依据 = evidence;
          freshBreakthrough = true;
        }
      }
    }
    let attemptedScores = 0, acceptedScores = 0;
    let acceptedBreakthrough = false;
    function reject(field, explanation) {
      if (old && Object.hasOwn(old, field)) relation[field] = old[field];
      else if (field === '好感') relation[field] = null;
      else delete relation[field];
      notices.push({ path: '/人际/' + name + '/' + field, message: explanation });
    }
    if (['男性', '女性'].includes(old?.性别) && relation.性别 !== old.性别) {
      reject('性别', '模型不能改写已确认性别来改变路线；明确纠错请由玩家使用变量编辑器。');
    }
    for (const [field, config] of [['好感', RELATIONSHIP_SCORING.affection], ['支援度', RELATIONSHIP_SCORING.support]]) {
      const value = relation[field], prior = old?.[field];
      if (value === prior || (value == null && prior == null)) continue;
      // 首次确认认识可以先建立空支援账；0 不是本轮计分，不要求协作依据。
      // 只豁免全新关系，旧记录缺数值仍必须由玩家核定。
      if (field === '支援度' && !old && value === config.initial) continue;
      attemptedScores++;
      if (typeof value !== 'number' || !Number.isFinite(value)) {
        reject(field, '已计分数值不能由模型清空；明确纠错请使用变量编辑器。');
        continue;
      }
      if (field === '支援度' && old && (typeof prior !== 'number' || !Number.isFinite(prior))) {
        reject(field, '旧记录支援度待核定，请由玩家在变量编辑器确认起始值；模型不能自行按旧字母倒填或从 0 重置。');
        continue;
      }
      const baseline = typeof prior === 'number' && Number.isFinite(prior) ? prior : config.initial;
      const delta = value - baseline;
      const withinRange = value >= config.min && value <= config.max && (field !== '支援度' || Number.isInteger(value));
      const usesBreakthrough = field === '好感' && Math.abs(delta) > config.majorMax && freshBreakthrough;
      const withinTurn = field === '好感' ? Math.abs(delta) <= config.majorMax || usesBreakthrough : delta >= 0 && delta <= config.majorMax;
      if (!withinRange || !withinTurn) {
        reject(field, field === '好感' ? '好感须在 0～1000；常规每轮最多变化 ±5。重大剧情突破须填写新的好感突破依据和变化依据，旧理由不能反复解锁；首次有效交往仍以 50 为起点。' : '支援度每人每轮最多增加 15，不能倒退或跨级补分；旧分值请先由玩家核定。');
      } else if (!evidence || repeated) {
        reject(field, repeated ? '本次计分依据与上次相同，未重复加减分；同一事件不得再次计分。' : '计分需要写明本次实际发生的互动或协作结果。');
      } else {
        acceptedScores++;
        if (usesBreakthrough) acceptedBreakthrough = true;
      }
    }
    // 只保留最近一次成功突破的理由。普通轮次和失败重试不消费、清空或替换它。
    if (!acceptedBreakthrough && breakthrough !== priorBreakthrough) {
      reject('好感突破依据', '本轮未完成好感突破，保留最近一次成功突破的依据；修正失败数值后可以重试。');
    }
    // 变化依据表示最近一次已成功计分的事件。整次计分失败时保留上一条，
    // 使模型修正数值后可以重试同一事件；若已有一项成功，则保留新依据防止重复。
    if (attemptedScores > 0 && acceptedScores === 0) {
      const priorEvidence = typeof old?.变化依据 === 'string' ? old.变化依据 : '';
      if (relation.变化依据 !== priorEvidence) {
        relation.变化依据 = priorEvidence;
        notices.push({ path: '/人际/' + name + '/变化依据', message: '本轮所有计分均未成功，已恢复上次计分依据；可修正数值后重试本次事件。' });
      }
    }
    if (typeof relation.支援度 === 'number') relation.羁绊阶段 = supportStage(relation.支援度);
    else if (old && relation.羁绊阶段 !== old.羁绊阶段) {
      relation.羁绊阶段 = old.羁绊阶段;
      notices.push({ path: '/人际/' + name + '/羁绊阶段', message: '支援度尚未核定，保留旧阶段；模型不能直接提升字母。' });
    } else if (!old && !['未定', '未建立'].includes(relation.羁绊阶段)) {
      relation.羁绊阶段 = '未定';
      notices.push({ path: '/人际/' + name + '/羁绊阶段', message: '新关系不能凭空授予字母阶段，请从已确认支援值累计。' });
    }
    // 计分或性别恢复后重新派生，不能留下本次被拒分数对应的高阶段。
    const romance = romanceStage(relation);
    if (romance !== null) relation.恋爱阶段 = romance;
    else if (Object.hasOwn(relation, '恋爱阶段')) {
      delete relation.恋爱阶段;
      notices.push({ path: '/人际/' + name + '/恋爱阶段', message: '只有已确认女性且好感已计分的记录可以拥有恋爱阶段；当前记录不进入恋爱路线。' });
    }
  }
  return notices;
}
export const INITIAL_STATE = {
  系统: { 结构版本: 3, 开局状态: '待建档', 主角模式: '未选择' },
  场景: { 当前卷: 1, 当前章: '待选择', 阶段: '未开始', 时间: '', 地点: '', 切入说明: '', 已发生事件: {} },
  玩家: {
    性别: '男性',
    姓名: '', 性格关键词: '', 处事风格: '', 所属: '', 固有灵装: '', 角色简介: '', 战斗风格: '',
    伐刀能力: { 能力系别: '', 能力本质: '', 共通限制: '', 招式: {} },
    其他能力: {},
    六维: Object.fromEntries(AXES.map(key => [key, ''])),
    综合初评: { 规则版本: 'R05-第一版', 分数: null, 等级: null, 拟定登记等级: null, 评定状态: '待填写六维', 待填写项: AXES.slice(0, 4) },
    登记等级: null,
  },
  人际: {},
};

export function createSchema(z) {
  const text = z.string();
  // 动态记录允许有名条目；固定对象全部 strict，禁止拼错路径后另造字段。
  const key = z.string().min(1).refine(value => !/[~/]/.test(value) && !['__proto__', 'prototype', 'constructor'].includes(value), '名称不能包含 /、~ 或保留键');
  const record = value => z.record(key, value);
  const skill = z.object({ 说明: text, 条件与代价: text, 掌握状态: z.enum(['待确认', '学习中', '已掌握']) }).strict();
  const knownProfile = z.object({ 身份: text.optional(), 登记等级: text.optional(), 灵装: text.optional(), 已知能力: text.optional() }).strict();
  const root = z.object({
    // MVU 更新过程临时注入的框架元数据；保留原值，不作为本卡业务结构校验。
    $internal: z.unknown().optional(),
    系统: z.object({ 结构版本: z.literal(3), 开局状态: z.enum(['待建档', '已建档']), 主角模式: z.enum(['未选择', '黑铁一辉', '自定义角色']) }).strict(),
    场景: z.object({
      当前卷: z.literal(1),
      当前章: z.enum(CHAPTERS),
      阶段: z.enum(['未开始', '进行中', '已结束']),
      时间: text, 地点: text, 切入说明: text.default(''),
      已发生事件: record(z.object({ 章段: z.enum(CHAPTERS.slice(1)), 结果: text.min(1), 参与者: z.array(text.min(1)), 知情者: z.array(text.min(1)) }).strict()),
    }).strict(),
    玩家: z.object({
      性别: z.literal('男性').default('男性'),
      姓名: text, 性格关键词: text, 处事风格: text, 所属: text, 固有灵装: text, 角色简介: text, 战斗风格: text,
      伐刀能力: z.object({ 能力系别: z.enum(['', '体能强化系', '自然干涉系', '概念干涉系', '因果干涉系']), 能力本质: text, 共通限制: text, 招式: record(skill) }).strict(),
      其他能力: record(skill),
      六维: z.object(Object.fromEntries(AXES.map(axis => [axis, z.enum(['', ...GRADES])]))).strict(),
      综合初评: z.object({
        规则版本: text, 分数: z.number().min(1).max(6).nullable(), 等级: z.enum(GRADES).nullable(), 拟定登记等级: z.enum(GRADES).nullable(),
        评定状态: z.enum(['待填写六维', '已计算', '原作档案']), 待填写项: z.array(z.enum(AXES.slice(0, 4))),
      }).strict(),
      登记等级: z.enum(GRADES).nullable(),
    }).strict(),
    人际: record(z.object({ 关系: text, 态度印象: text, 性别: z.enum(['未知', '男性', '女性']).optional(), 好感: z.number().min(RELATIONSHIP_SCORING.affection.min).max(RELATIONSHIP_SCORING.affection.max).nullable(), 支援度: z.number().int().min(RELATIONSHIP_SCORING.support.min).max(RELATIONSHIP_SCORING.support.max).nullable().optional(), 羁绊阶段: z.enum(['未定', '未建立', 'C', 'B', 'A', 'S']), 恋爱阶段: z.enum(RELATIONSHIP_SCORING.romance.stages.map(item => item.stage)).optional(), 好感突破依据: text.optional(), 变化依据: text, 已知资料: knownProfile.optional() }).strict()),
  }).strict().superRefine((state, ctx) => {
    const issue = (path, message) => ctx.addIssue({ code: 'custom', path, message });
    if (state.系统.开局状态 === '已建档' && (state.系统.主角模式 === '未选择' || !state.玩家.姓名.trim())) issue(['系统', '开局状态'], '已建档需要已选身份和非空姓名');
    if (state.场景.阶段 !== '未开始' && state.系统.开局状态 !== '已建档') issue(['场景', '阶段'], '先完成建档，再开始剧情');
    if (state.场景.当前章 === '待选择' && state.场景.阶段 !== '未开始') issue(['场景', '阶段'], '未选择章段时不能开始或结束剧情');
    const chapter = CHAPTERS.indexOf(state.场景.当前章);
    for (const [name, event] of Object.entries(state.场景.已发生事件)) {
      if (CHAPTERS.indexOf(event.章段) > chapter) issue(['场景', '已发生事件', name, '章段'], '不能把后续章段事件写成已发生');
    }
    if (state.系统.主角模式 === '黑铁一辉' && Object.hasOwn(state.人际, '黑铁一辉')) issue(['人际', '黑铁一辉'], '一辉模式不能新建另一个一辉的人际记录');
    for (const [name, relation] of Object.entries(state.人际)) {
      if (['C', 'B', 'A', 'S'].includes(relation.羁绊阶段) && !relation.变化依据.trim()) issue(['人际', name, '变化依据'], '已成立羁绊必须有本局依据');
      if (relation.恋爱阶段 !== undefined && romanceStage(relation) === null) issue(['人际', name, '恋爱阶段'], '只有已确认女性且好感为有效数值时才能派生恋爱阶段；男性、性别未知或好感待核定时不能预写。');
    }
  });
  // 上游桥接器对直接传入的 ZodObject 会改用 looseObject。
  // preprocess 保留本卡固定字段的 strict 校验；在 record 可能忽略保留键前明确拒绝。
  return z.preprocess((value, ctx) => {
    function inspect(node, path = []) {
      if (!node || typeof node !== 'object') return;
      for (const name of Object.keys(node)) {
        if (path.length === 0 && name === '$internal') continue;
        if (['__proto__', 'prototype', 'constructor'].includes(name)) ctx.addIssue({ code: 'custom', path: [...path, name], message: '不接受保留键，未丢弃原始数据' });
        else inspect(node[name], [...path, name]);
      }
    }
    inspect(value);
    // 数值已经存在才派生阶段。旧记录缺支援度或为 null 时完全保留，绝不凭字母倒填分。
    // 只复制待归一化对象，schema.parse 不修改调用方或框架 $internal 快照。
    if (!value?.人际 || typeof value.人际 !== 'object' || Array.isArray(value.人际)) return value;
    const relations = Object.fromEntries(Object.entries(value.人际).map(([name, relation]) => {
      const stage = supportStage(relation?.支援度);
      const romance = romanceStage(relation);
      return [name, stage !== '未定' || romance !== null ? { ...relation, ...(stage !== '未定' ? { 羁绊阶段: stage } : {}), ...(romance !== null ? { 恋爱阶段: romance } : {}) } : relation];
    }));
    return { ...value, 人际: relations };
  }, root);
}

// 离线 v2 迁移：拒绝未识别数据，不覆盖聊天，不凭招式名猜测多招式分隔。
export function migrateV2(input, z) {
  const schema = createSchema(z);
  if (input?.系统?.结构版本 === 3) return schema.parse(structuredClone(input));
  if (input?.系统?.结构版本 !== 2) throw new Error('仅支持中文结构 v2 → v3；英文或未知版本须先核对原始数据');
  const next = structuredClone(input);
  next.系统.结构版本 = 3;
  next.场景 = { 当前章: '待选择', 阶段: '未开始', 已发生事件: {}, ...next.场景 };
  const p = next.玩家;
  p.伐刀能力 = { 能力系别: p.能力系别 ?? '', 能力本质: p.能力机制 ?? '', 共通限制: p.限制与代价 ?? '', 招式: {} };
  if (p.伐刀绝技?.trim()) p.伐刀能力.招式[p.伐刀绝技.trim()] = { 说明: '', 条件与代价: '', 掌握状态: '待确认' };
  p.其他能力 = {};
  for (const field of ['伐刀绝技', '能力系别', '能力机制', '限制与代价']) delete p[field];
  next.人际 ??= {};
  for (const relation of Object.values(next.人际)) {
    const old = relation.羁绊阶段;
    if (!['未定', '未建立', 'C', 'B', 'A', 'S'].includes(old)) {
      relation.羁绊阶段 = '未定';
      relation.变化依据 = `旧存档阶段：${old ?? '未记录'}。尚未确认 C/B/A/S 对应，保留原描述待核对。`;
    } else relation.变化依据 ??= '';
    relation.好感 ??= null;
  }
  return schema.parse(next);
}
