// 只读当前聊天最新助手楼层的当前回复页；变量和来源来自同一次消息读取。
// 接口依据：Tavern Helper 4.8.19 @types/function/chat_message.d.ts。
// 读取不依赖建档写入权限，也不回退到旧楼层、chat 或 global 变量。
function createTerminalStateReader(readMessages, getContext) {
  return function readTerminalState() {
    if (typeof readMessages !== 'function') throw new Error('酒馆助手的消息读取接口尚未就绪');
    var context = getContext();
    if (!context || !Array.isArray(context.chat) || !context.chat.length) throw new Error('当前没有聊天记录');
    for (var id = context.chat.length - 1; id >= 0; id--) {
      var messages = readMessages(id, { role: 'assistant', include_swipes: true });
      if (!Array.isArray(messages)) throw new Error('消息读取接口返回格式不受支持');
      var message = messages[0];
      if (!message) continue;
      if (message.message_id !== id || !Number.isInteger(message.swipe_id) || message.swipe_id < 0 ||
          !Array.isArray(message.swipes) || message.swipe_id >= message.swipes.length) {
        throw new Error('当前助手回复的楼层或回复页标识不完整，无法确认 MVU 槽');
      }
      var source = {
        messageId: message.message_id,
        swipeId: message.swipe_id,
        swipeCount: message.swipes.length,
        chatId: typeof context.chatId === 'string' ? context.chatId : null
      };
      var data = Array.isArray(message.swipes_data) ? message.swipes_data[message.swipe_id] : null;
      var state = data && data.stat_data;
      if (!state || typeof state !== 'object' || Array.isArray(state)) {
        var error = new Error('当前助手回复尚无 MVU 数据，等待变量更新后重读');
        error.source = source;
        throw error;
      }
      var result = {};
      ['系统', '场景', '玩家', '人际'].forEach(function(key) {
        if (Object.prototype.hasOwnProperty.call(state, key)) result[key] = structuredClone(state[key]);
      });
      return { state: result, source: source };
    }
    throw new Error('当前聊天没有助手楼层');
  };
}
