"use strict";

var bridge = null;
var stat = {};
var currentStack = ['scr-home'];
var blazerSubTab = 'overview';
var activeChat = null;
var dataStatus = 'loading';
var dataError = '';
var stateSource = null;
var expandedPeople = new Set();

function sourceKey(source) {
  return source ? JSON.stringify([source.chatId, source.messageId, source.swipeId]) : '';
}

function sourceLabel(source) {
  if (!source) return dataStatus === 'ready' ? '本局已保存档案' : '正在读取当前回复';
  return '第 ' + source.messageId + ' 楼 · 回复 ' + (source.swipeId + 1) + '/' + source.swipeCount +
    (dataStatus === 'ready' ? ' · 已保存 MVU' : ' · 等待本回复的 MVU');
}

function rememberPersonExpansion(card) {
  var body = document.getElementById('blazer-body');
  if (!body || !body.contains(card) || card.getAttribute('data-source') !== sourceKey(stateSource)) return;
  var name = card.getAttribute('data-person');
  if (card.open) expandedPeople.add(name);
  else expandedPeople.delete(name);
}

function esc(s) {
  if (s == null) return '';
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function toast(msg) {
  var t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('on');
  clearTimeout(t._timer);
  t._timer = setTimeout(function() { t.classList.remove('on'); }, 2200);
}

// 导航操作
function openApp(appId) {
  var scrMap = {
    'blazer': 'scr-blazer',
    'lime': 'scr-lime',
    'moments': 'scr-moments',
    'bbs': 'scr-bbs',
    'schedule': 'scr-schedule',
    'gallery': 'scr-gallery',
    'worldbook': 'scr-worldbook',
    'settings': 'scr-settings'
  };
  var target = scrMap[appId];
  if (!target) return;

  if (appId === 'blazer') renderBlazer();
  else if (appId === 'lime') renderLime();
  else if (appId === 'moments') renderMoments();
  else if (appId === 'bbs') renderBbs();
  else if (appId === 'schedule') renderSchedule();
  else if (appId === 'gallery') renderGallery();
  else if (appId === 'worldbook') renderWorldbook();
  else if (appId === 'settings') renderSettings();

  var curEl = document.getElementById(currentStack[currentStack.length - 1]);
  var targetEl = document.getElementById(target);
  if (curEl && targetEl && curEl !== targetEl) {
    curEl.classList.remove('on');
    curEl.classList.add('under');
    targetEl.classList.remove('under');
    targetEl.classList.add('on');
    currentStack.push(target);
  }
}

function goBack() {
  if (currentStack.length <= 1) return;
  var curId = currentStack.pop();
  var curEl = document.getElementById(curId);
  var prevId = currentStack[currentStack.length - 1];
  var prevEl = document.getElementById(prevId);
  if (curEl) {
    curEl.classList.remove('on');
    curEl.classList.remove('under');
  }
  if (prevEl) {
    prevEl.classList.remove('under');
    prevEl.classList.add('on');
  }
}

function goHome() {
  while (currentStack.length > 1) {
    var curId = currentStack.pop();
    var el = document.getElementById(curId);
    if (el) { el.classList.remove('on'); el.classList.remove('under'); }
  }
  var home = document.getElementById('scr-home');
  if (home) { home.classList.remove('under'); home.classList.add('on'); }
  activeChat = null;
}

// ===== 数据解析引擎 (落第骑士 MVU 数据规范) =====
function resolvePlayer() {
  var p = stat && stat.玩家 || {};
  var ability = p.伐刀能力 || {};
  var techniques = ability.招式 || {};
  return {
    name: p.姓名 || '未建档',
    affiliation: p.所属 || '所属未登记',
    rank: p.登记等级 || '—',
    device: p.固有灵装 || '灵装未登记',
    arts: Object.keys(techniques).join('、') || '尚无命名招式',
    bio: p.角色简介 || '完成开局建档后，这里显示本局角色档案。',
    mechanism: ability.能力本质 || '能力本质未登记',
    category: ability.能力系别 || '系别未登记',
    cost: ability.共通限制 || '共通限制未登记',
    style: p.战斗风格 || '战斗风格未登记',
    techniques: techniques,
    otherAbilities: p.其他能力 || {},
    sixAxes: p.六维 || {}
  };
}

function resolveScene() {
  var s = stat && stat.场景 || {};
  return {
    time: s.时间 || '时间未确认',
    location: s.地点 || '地点未确认',
    volume: s.当前卷 === 1 ? '第一卷' : '卷数未确认',
    chapter: s.当前章 || '待选择',
    phase: s.阶段 || '未读取'
  };
}

// 刷新首页学生证
function updateHomeScreen() {
  var pl = resolvePlayer();
  var sc = resolveScene();

  var nameEl = document.getElementById('home-name');
  if (nameEl) nameEl.textContent = pl.name;

  var avaEl = document.getElementById('home-ava');
  if (avaEl) avaEl.textContent = pl.name.slice(0, 1);

  var classEl = document.getElementById('home-class');
  if (classEl) classEl.textContent = pl.affiliation;

  var rankEl = document.getElementById('home-rank');
  if (rankEl) rankEl.textContent = pl.rank + '级';

  var devEl = document.getElementById('home-device');
  if (devEl) devEl.textContent = pl.device;

  var artEl = document.getElementById('home-art');
  if (artEl) artEl.textContent = pl.arts;

  var clkEl = document.getElementById('sys-clk');
  if (clkEl) clkEl.textContent = sc.time;

  // 六维标签药丸
  var axes = pl.sixAxes;
  var map = [
    { id: 'pill-atk', label: '攻', val: axes['攻击力'] || '—' },
    { id: 'pill-def', label: '防', val: axes['防御力'] || '—' },
    { id: 'pill-mp',  label: '魔', val: axes['魔力量'] || '—' },
    { id: 'pill-ctrl',label: '控', val: axes['魔力控制'] || '—' },
    { id: 'pill-phy', label: '体', val: axes['体能'] || '—' },
    { id: 'pill-lck', label: '运', val: axes['运气'] || '—' }
  ];
  map.forEach(function(item) {
    var el = document.getElementById(item.id);
    if (el) {
      el.className = 'axis-pill rank-' + item.val;
      el.innerHTML = item.label + '<b>' + esc(item.val) + '</b>';
    }
  });
}

// ===== 伐刀者档案 (Blazer ID) =====
function switchBlazerTab(tab) {
  blazerSubTab = tab;
  document.querySelectorAll('.subtab').forEach(function(el) {
    el.classList.toggle('on', el.getAttribute('data-btab') === tab);
  });
  renderBlazer();
}

function rankToValue(r) {
  var rank = String(r == null ? '' : r).normalize('NFKC').trim().toUpperCase();
  if (!/^(A|[B-F]\+?)$/.test(rank)) return null;
  var m = { A: 6, B: 5, C: 4, D: 3, E: 2, F: 1 };
  return m[rank.charAt(0)] + (rank.endsWith('+') ? 0.5 : 0);
}

function renderRelationshipMetrics(relation) {
  var rules = bridge && bridge.relationshipRules;
  if (!rules || typeof bridge.supportStage !== 'function') return '<p class="gba-unknown">计分规则尚未连接。</p>';
  function metric(label, value, config, kind, unknown) {
    var known = typeof value === 'number' && Number.isFinite(value) && value >= config.min && value <= config.max &&
      (kind !== 'support' || Number.isInteger(value));
    return '<div class="gba-metric"><span>' + label + '</span>' +
      (known ? '<strong>' + value + ' / ' + config.max + '</strong>' : '<span class="gba-unknown">' + unknown + '</span>') + '</div>' +
      (known ? '<div class="gba-meter" data-kind="' + kind + '" role="meter" aria-label="' + label + '" aria-valuemin="' + config.min +
        '" aria-valuemax="' + config.max + '" aria-valuenow="' + value + '"><span style="width:' +
        ((value - config.min) / (config.max - config.min) * 100).toFixed(2) + '%"></span></div>' : '');
  }
  var stage = bridge.supportStage(relation.支援度);
  var knownSupport = stage !== '未定';
  var next = knownSupport && rules.support.stages.find(function(item) { return relation.支援度 < item.min; });
  var stageText = knownSupport ? stage : '待核定' + (relation.羁绊阶段 && relation.羁绊阶段 !== '未定' ? '（原记录：' + esc(relation.羁绊阶段) + '）' : '');
  return '<section class="gba-bond-panel" aria-label="好感与支援状态">' +
    metric('好感', relation.好感, rules.affection, 'affection', '未计分') +
    (typeof relation.好感 !== 'number' ? '<p class="gba-note">下次有效交往以 ' + rules.affection.initial + ' 为起点，只计算当次变化。</p>' : '') +
    metric('支援度', relation.支援度, rules.support, 'support', '待核定起点') +
    '<div class="gba-metric"><span>支援阶段</span><strong>' + stageText + '</strong></div>' +
    (knownSupport ? '<ol class="gba-support-track" aria-label="支援阶段门槛">' + rules.support.stages.map(function(item) {
      return '<li data-achieved="' + (relation.支援度 >= item.min) + '">' + esc(item.stage) + '<small>' + item.min + '</small></li>';
    }).join('') + '</ol><p class="gba-note">' + (next ? '距 ' + esc(next.stage) + ' 还需 ' + (next.min - relation.支援度) + ' 点支援。' : '已达到最高支援。') +
      'S 不自动表示恋爱。</p>' : '<p class="gba-note">旧字母不折算为分数；确认起点后再累计。</p>') +
    renderRomanceStatus(relation, rules) +
    (relation.变化依据 ? '<p class="gba-note">最近变化依据：' + esc(relation.变化依据) + '</p>' : '') +
    (relation.好感突破依据 ? '<p class="gba-note">最近一次好感突破依据：' + esc(relation.好感突破依据) + '</p>' : '') + '</section>';
}

function renderRomanceStatus(relation, rules) {
  if (relation.性别 === '男性') return '';
  if (relation.性别 !== '女性') return '<p class="gba-unknown">性别尚未记录，暂不显示恋爱阶段。</p>';
  if (!rules.romance || typeof bridge.romanceStage !== 'function') return '<p class="gba-unknown">恋爱阶段规则尚未连接。</p>';
  var stage = bridge.romanceStage(relation);
  if (!stage) return '<div class="gba-romance-panel"><div class="gba-metric"><span>恋爱阶段</span><span class="gba-unknown">好感未计分</span></div></div>';
  var next = rules.romance.stages.find(function(item) { return relation.好感 < item.min; });
  return '<section class="gba-romance-panel" aria-label="女性恋爱阶段">' +
    '<div class="gba-metric"><span>恋爱阶段</span><strong>' + esc(stage) + '</strong></div>' +
    '<ol class="gba-support-track gba-romance-track" aria-label="恋爱阶段好感门槛">' + rules.romance.stages.map(function(item) {
      return '<li data-achieved="' + (relation.好感 >= item.min) + '">' + esc(item.stage) + '<small>' + item.min + '</small></li>';
    }).join('') + '</ol><p class="gba-note">' + (next ? '距“' + esc(next.stage) + '”还需 ' + (next.min - relation.好感) + ' 点好感。' : '已达到最高恋爱阶段。') +
    '依好感显示；支援度单独累计。</p></section>';
}

function renderBlazer() {
  var body = document.getElementById('blazer-body');
  if (!body) return;
  body.classList.add('gba-status');
  var pl = resolvePlayer();
  var sc = resolveScene();

  var headRank = document.getElementById('blazer-head-rank');
  if (headRank) headRank.textContent = pl.rank + '级 伐刀者 // ' + pl.affiliation;
  var headSource = document.getElementById('blazer-head-source');
  if (headSource) headSource.textContent = sourceLabel(stateSource);

  if (blazerSubTab === 'overview') {
    body.innerHTML = 
      '<div class="card1">' +
        '<div class="ct">本局角色档案</div>' +
        '<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">' +
          '<div class="card-avatar" style="width:54px;height:54px;font-size:22px;">' + esc(pl.name.slice(0, 1)) + '</div>' +
          '<div>' +
            '<div style="font-size:17px;font-weight:800;color:var(--ink);">' + esc(pl.name) + ' <span class="card-rank-badge">' + esc(pl.rank) + '级</span></div>' +
            '<div style="font-size:12px;color:var(--muted);margin-top:2px;">所属：' + esc(pl.affiliation) + '</div>' +
            '<div style="font-size:12px;color:var(--sky);margin-top:2px;">灵装：' + esc(pl.device) + '</div>' +
          '</div>' +
        '</div>' +
        '<div style="font-size:12.5px;color:var(--ink2);line-height:1.6;background:var(--card2);padding:10px 12px;border-radius:10px;">' +
          esc(pl.bio) +
        '</div>' +
      '</div>' +

      '<div class="card1">' +
        '<div class="ct">当前场景</div>' +
        '<div style="font-size:12.5px;color:var(--ink2);line-height:1.6;">' +
          '<div><i class="ti ti-map-pin" style="color:#ef4444;margin-right:4px;"></i> 地点：<b>' + esc(sc.location) + '</b></div>' +
          '<div style="margin-top:4px;"><i class="ti ti-clock" style="color:#38bdf8;margin-right:4px;"></i> 时间：' + esc(sc.time) + '</div>' +
          '<div style="margin-top:4px;"><i class="ti ti-trophy" style="color:#f59e0b;margin-right:4px;"></i> 进度：' + esc(sc.volume + ' · ' + sc.chapter + ' · ' + sc.phase) + '</div>' +
        '</div>' +
      '</div>';
  } else if (blazerSubTab === 'radar') {
    var axesOrder = ['攻击力', '防御力', '魔力量', '魔力控制', '体能', '运气'];
    var cx = 130, cy = 115, maxRadius = 75;
    var points = [];
    var webCircles = [1/6, 2/6, 3/6, 4/6, 5/6, 1];

    var webSvg = '';
    webCircles.forEach(function(lvl) {
      var r = maxRadius * lvl;
      var pts = [];
      for (var i = 0; i < 6; i++) {
        var angle = (Math.PI / 3) * i - Math.PI / 2;
        pts.push((cx + r * Math.cos(angle)).toFixed(1) + ',' + (cy + r * Math.sin(angle)).toFixed(1));
      }
      webSvg += '<polygon class="radar-web" points="' + pts.join(' ') + '"/>';
    });

    var labelsSvg = '';
    var pointNodes = '';
    for (var i = 0; i < 6; i++) {
      var angle = (Math.PI / 3) * i - Math.PI / 2;
      var spokeX = (cx + maxRadius * Math.cos(angle)).toFixed(1);
      var spokeY = (cy + maxRadius * Math.sin(angle)).toFixed(1);
      webSvg += '<line class="radar-web-spoke" x1="' + cx + '" y1="' + cy + '" x2="' + spokeX + '" y2="' + spokeY + '"/>';

      var axisName = axesOrder[i];
      var rk = pl.sixAxes[axisName] || '—';
      var val = rankToValue(rk);
      if (val !== null) {
        var ptR = (val / 6.0) * maxRadius;
        var ptX = cx + ptR * Math.cos(angle);
        var ptY = cy + ptR * Math.sin(angle);
        points.push(ptX.toFixed(1) + ',' + ptY.toFixed(1));
        pointNodes += '<circle class="radar-point" cx="' + ptX.toFixed(1) + '" cy="' + ptY.toFixed(1) + '" r="3.5"/>';
      }

      var labelR = maxRadius + 22;
      var lx = cx + labelR * Math.cos(angle);
      var ly = cy + labelR * Math.sin(angle);
      labelsSvg += '<text class="radar-label" x="' + lx.toFixed(1) + '" y="' + (ly - 6).toFixed(1) + '">' + axisName + '</text>';
      labelsSvg += '<text class="radar-rank-badge" x="' + lx.toFixed(1) + '" y="' + (ly + 7).toFixed(1) + '">' + (val === null ? '待确认' : esc(rk)) + '</text>';
    }

    var polygonSvg = points.length === 6 ? '<polygon class="radar-polygon" points="' + points.join(' ') + '"/>' : '';

    body.innerHTML = 
      '<div class="card1">' +
        '<div class="ct">伐刀者 A~F 六维能力雷达评定</div>' +
        '<div class="radar-container">' +
          '<svg class="radar-svg" viewBox="0 0 260 230" role="img" aria-label="六维等级雷达：B+ 介于 B 与 A；未知项不绘制数值。">' +
            webSvg +
            polygonSvg +
            pointNodes +
            labelsSvg +
          '</svg>' +
        '</div>' +
        '<div style="font-size:12px;color:var(--muted);text-align:center;margin-top:4px;">' +
          'B+ 介于 B 与 A。坐标采用本卡 R05：F=1 至 A=6，+ 加 0.5；不代表能力倍率。' +
          (points.length < 6 ? '未确认项不绘点，资料齐全后再连成面。' : '') +
        '</div>' +
      '</div>';
  } else if (blazerSubTab === 'device') {
    function listSkills(records) {
      var names = Object.keys(records);
      if (!names.length) return '<div class="noble-art-desc">尚未登记具体能力。</div>';
      return names.map(function(name) {
        var skill = records[name] || {};
        return '<div class="noble-art-block"><div class="noble-art-title">' + esc(name) + ' · ' + esc(skill.掌握状态 || '待确认') + '</div>' +
          '<div class="noble-art-desc">' + esc(skill.说明 || '说明未登记') + '</div>' +
          '<div class="noble-art-desc">条件与代价：' + esc(skill.条件与代价 || '未登记') + '</div></div>';
      }).join('');
    }
    body.innerHTML = '<div class="card1"><div class="ct">固有灵装</div><div class="noble-art-title">' + esc(pl.device) + '</div>' +
      '<div class="ct" style="margin-top:14px;">伐刀能力 · ' + esc(pl.category) + '</div><p>' + esc(pl.mechanism) + '</p>' +
      '<p>共通限制：' + esc(pl.cost) + '</p>' + listSkills(pl.techniques) +
      '<div class="ct" style="margin-top:14px;">其他能力</div>' + listSkills(pl.otherAbilities) + '</div>';
  } else if (blazerSubTab === 'roster') {
    var relations = stat && stat.人际 || {};
    var names = Object.keys(relations).filter(function(name) {
      // 一辉模式中的自己不作为独立 NPC 显示；不修改原始存档。
      return !(stat.系统 && stat.系统.主角模式 === '黑铁一辉' && name === '黑铁一辉');
    });
    if (dataStatus !== 'ready') {
      body.innerHTML = '<div class="card1" role="status">' + esc(dataStatus === 'error' ? '名册未能读取：' + dataError : '正在读取本局名册…') + '</div>';
      return;
    }
    body.innerHTML = names.length ? '<div class="roster-list">' + names.map(function(name) {
      var relation = relations[name] || {};
      var known = relation.已知资料 || {};
      var grade = typeof known.登记等级 === 'string' ? known.登记等级.trim() : '';
      var details = [['身份', '身份'], ['灵装', '灵装'], ['已知能力', '已知能力']].map(function(field) {
        var value = known[field[0]];
        return typeof value === 'string' && value.trim() ? '<div class="roster-device">' + field[1] + '：' + esc(value) + '</div>' : '';
      }).join('');
      return '<details class="roster-card gba-contact" data-person="' + esc(name) + '" data-source="' + esc(sourceKey(stateSource)) + '"' +
        (expandedPeople.has(name) ? ' open' : '') + ' ontoggle="rememberPersonExpansion(this)"><summary class="gba-contact-summary">' +
        '<div class="roster-ava" aria-hidden="true">' + esc(name.slice(0, 1)) + '</div><div class="roster-info">' +
        '<div class="roster-name">' + esc(name) + (grade ? ' <span class="card-rank-badge">' + esc(grade) + '</span>' : '') + '</div>' +
        '<div class="roster-device">与你的关系：' + esc(relation.关系 || '尚未确认') + '</div></div>' +
        '<span class="gba-disclosure" aria-hidden="true">资料</span></summary><div class="gba-contact-body">' +
        (relation.态度印象 ? '<div class="roster-device">印象：' + esc(relation.态度印象) + '</div>' : '') +
        details + (details ? '' : '<p class="gba-unknown">尚未获知更多身份或能力资料。</p>') + renderRelationshipMetrics(relation) + '</div></details>';
    }).join('') + '</div>' : '<div class="card1">本局尚无已记录的人际关系。</div>';
  }
}

// ===== 破军 LIME 通讯 =====
function renderLime() {
  var body = document.getElementById('lime-body');
  if (!body) return;
  document.getElementById('lime-title').textContent = activeChat || '破军 LIME';
  document.getElementById('lime-sub').textContent = '通讯记录尚未接入';
  body.innerHTML = '<div class="card1"><div class="ct">通讯</div>本局尚未接入私人通讯记录。请在酒馆聊天中进行角色交流。</div>';
}
function openLimeChat(name) { activeChat = name; renderLime(); }
function renderLimeChatView(name) { activeChat = name; renderLime(); }
function handleChatKey(e) { if (e.key === 'Enter') sendChatMsg(); }
function sendChatMsg() { toast('通讯尚未接入，请在酒馆聊天中发送。'); }
function sendQuickAction() { sendChatMsg(); }

// ===== 学园圈 (Moments) =====
function renderMoments() {
  var body = document.getElementById('moments-body');
  if (body) body.innerHTML = '<div class="card1"><div class="ct">学园圈</div>本局尚未接入动态记录。</div>';
}
function postMomentPrompt() { toast('动态发布尚未接入。'); }

// ===== 破军 BBS 论坛 =====
function renderBbs() {
  var body = document.getElementById('bbs-body');
  if (body) body.innerHTML = '<div class="card1"><div class="ct">破军 BBS</div>本局尚未接入论坛记录。</div>';
}
function refreshBbs() { renderBbs(); toast('当前没有可读取的论坛记录。'); }

// ===== 第一卷剧情记录 =====
function renderSchedule() {
  var body = document.getElementById('schedule-body');
  if (!body) return;
  var scene = resolveScene();
  var events = stat && stat.场景 && stat.场景.已发生事件 || {};
  var names = Object.keys(events);
  body.innerHTML = '<div class="card1"><div class="ct">当前剧情</div><div>' + esc(scene.volume + ' · ' + scene.chapter + ' · ' + scene.phase) + '</div>' +
    '<p>' + esc(scene.time + ' · ' + scene.location) + '</p><button type="button" onclick="openStoryControls()">展开剧情控制</button></div>' +
    '<div class="card1"><div class="ct">已发生事件</div>' + (names.length ? names.map(function(name) {
      var event = events[name] || {};
      return '<div class="noble-art-block"><div class="noble-art-title">' + esc(name) + ' · ' + esc(event.章段 || '') + '</div>' +
        '<div class="noble-art-desc">' + esc(event.结果 || '') + '</div></div>';
    }).join('') : '尚无已记录事件。') + '</div>';
}
function openStoryControls() {
  if (bridge && bridge.ui && typeof bridge.ui.openStoryControls === 'function') bridge.ui.openStoryControls();
}

// ===== 灵装画廊 (Gallery) =====
function renderGallery() {
  var body = document.getElementById('gallery-body');
  if (!body) return;

  body.innerHTML = 
    '<div class="card1">' +
      '<div class="ct">灵装图鉴 · 图片尚未接入</div>' +
      '<div style="display:grid;grid-template-columns:repeat(2, 1fr);gap:10px;margin-top:8px;">' +
        '<div style="background:var(--card2);height:120px;border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--muted);font-size:12px;">' +
          '<i class="ti ti-photo" style="font-size:28px;color:#ef4444;margin-bottom:4px;"></i>' +
          '<span>灵装显现 · 阴铁</span>' +
        '</div>' +
        '<div style="background:var(--card2);height:120px;border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--muted);font-size:12px;">' +
          '<i class="ti ti-flame" style="font-size:28px;color:#f59e0b;margin-bottom:4px;"></i>' +
          '<span>一刀修罗 · 爆发</span>' +
        '</div>' +
      '</div>' +
    '</div>';
}

// ===== 世界之理 (Worldbook) =====
function renderWorldbook() {
  var body = document.getElementById('worldbook-body');
  if (!body) return;

  body.innerHTML = 
    '<div class="card1">' +
      '<div class="ct">设定资料目录 · 请以本卡世界书为准</div>' +
      '<div style="font-size:12.5px;color:var(--ink2);line-height:1.6;">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--hair);">' +
          '<span>落第骑士英雄谭 · 世界观设定</span>' +
          '<span style="color:#10b981;font-weight:700;">资料条目</span>' +
        '</div>' +
        '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--hair);">' +
          '<span>破军学园 · 选拔赛校规规则</span>' +
          '<span style="color:#10b981;font-weight:700;">资料条目</span>' +
        '</div>' +
        '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">' +
          '<span>伐刀者能力体系与魔力量度</span>' +
          '<span style="color:#10b981;font-weight:700;">资料条目</span>' +
        '</div>' +
      '</div>' +
    '</div>';
}

// ===== 终端配置 (Settings) =====
function renderSettings() {
  var body = document.getElementById('settings-body');
  if (!body) return;

  body.innerHTML = 
    '<div class="card1">' +
      '<div class="ct">视觉与个性化</div>' +
      '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--hair);">' +
        '<span>色彩主题风格</span>' +
        '<button onclick="toggleTheme()" style="padding:4px 10px;background:var(--card2);border-radius:6px;font-size:12px;color:var(--ink);">' +
          '切换 黑底 / 白底' +
        '</button>' +
      '</div>' +
      '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">' +
        '<span>窗口与悬浮球位置</span>' +
        '<button onclick="recenterWindow()" style="padding:4px 10px;background:rgba(239,68,68,0.2);color:#fca5a5;border:1px solid rgba(239,68,68,0.4);border-radius:6px;font-size:12px;">' +
          '重置居中' +
        '</button>' +
      '</div>' +
    '</div>' +
    '<div class="card1">' +
      '<div class="ct">系统版本信息</div>' +
      '<div style="font-size:12px;color:var(--muted);line-height:1.6;">' +
        '<div>破军学园伐刀者便携智能终端 OS</div>' +
        '<div>版本：' + (bridge && bridge.version ? 'v' + esc(bridge.version) : '尚未连接') + ' MONO ADV · 黑白轮盘版</div>' +
        '<div>内核驱动：TavernHelper / MVU Data Bridge</div>' +
      '</div>' +
    '</div>';
}

function toggleTheme() {
  var cur = document.documentElement.getAttribute('data-rk-theme');
  var next = cur === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-rk-theme', next);
  toast('已切换至 ' + (next === 'light' ? '黑白纸面' : '黑白墨色') + ' 主题');
}

function recenterWindow() {
  if (bridge && bridge.ui && typeof bridge.ui.recenter === 'function') {
    bridge.ui.recenter();
  }
  toast('终端位置已恢复屏幕中央');
}

// 引导启动函数：仅缓存本次显示数据，切换聊天或读取失败时清空。
var bridgeRevision = 0;
var bridgeUnsubscribe = null;
var stateSignature = '';
function refreshTerminalView() {
  updateHomeScreen();
  var renderers = { 'scr-blazer': renderBlazer, 'scr-lime': renderLime, 'scr-moments': renderMoments, 'scr-bbs': renderBbs, 'scr-schedule': renderSchedule };
  var render = renderers[currentStack[currentStack.length - 1]];
  if (render) render();
}
function refreshTerminalState(event) {
  var revision = ++bridgeRevision;
  if (!event || event.reset) {
    stat = {};
    stateSource = null;
    expandedPeople.clear();
    stateSignature = '';
    dataStatus = 'loading';
    dataError = '';
    refreshTerminalView();
  }
  if (!bridge || (typeof bridge.getSnapshot !== 'function' && typeof bridge.getStat !== 'function')) return Promise.resolve();
  var currentBridge = bridge;
  return Promise.resolve().then(function() {
    return typeof currentBridge.getSnapshot === 'function' ? currentBridge.getSnapshot() :
      Promise.resolve(currentBridge.getStat()).then(function(state) { return { state: state, source: null }; });
  }).then(function(snapshot) {
    if (revision !== bridgeRevision) return;
    var signature = JSON.stringify(snapshot);
    if (signature === stateSignature && dataStatus === 'ready') return;
    if (sourceKey(stateSource) !== sourceKey(snapshot.source)) expandedPeople.clear();
    stateSource = snapshot.source || null;
    stateSignature = signature;
    stat = snapshot.state || {};
    dataStatus = 'ready';
    dataError = '';
    refreshTerminalView();
  }).catch(function(error) {
    if (revision !== bridgeRevision) return;
    stat = {};
    stateSource = error && error.source || null;
    expandedPeople.clear();
    stateSignature = '';
    dataStatus = 'error';
    dataError = error && error.message || '当前回复的数据不可用';
    refreshTerminalView();
  });
}
window.RKBoot = function(b) {
  if (typeof bridgeUnsubscribe === 'function') bridgeUnsubscribe();
  bridge = b;
  refreshTerminalState();
  bridgeUnsubscribe = bridge && typeof bridge.onUpdate === 'function' ? bridge.onUpdate(refreshTerminalState) : null;
};
window.addEventListener('pagehide', function() {
  bridgeRevision++;
  if (typeof bridgeUnsubscribe === 'function') bridgeUnsubscribe();
  bridgeUnsubscribe = null;
});

// 默认首屏就绪
updateHomeScreen();
