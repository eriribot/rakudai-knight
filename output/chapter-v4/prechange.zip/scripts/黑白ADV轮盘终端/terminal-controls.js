
/* MONO ADV controls: menu keyboard operation and UI-only status badge. */
(function () {
  var root = document.querySelector('.home-content');
  document.querySelectorAll('[data-layout-choice]').forEach(function (button) {
    button.addEventListener('click', function () {
      var layout = button.getAttribute('data-layout-choice');
      root.setAttribute('data-layout', layout);
      document.querySelectorAll('[data-layout-choice]').forEach(function (b) {
        b.setAttribute('aria-pressed', b === button ? 'true' : 'false');
      });
    });
  });
  var items = Array.from(document.querySelectorAll('.mono-sector'));
  items.forEach(function (item, index) {
    function setLabel() {
      document.getElementById('mono-wheel-label').textContent = item.getAttribute('data-label');
      items.forEach(function (it) { it.setAttribute('tabindex', it === item ? '0' : '-1'); });
    }
    item.addEventListener('pointerenter', setLabel);
    item.addEventListener('focus', setLabel);
    item.addEventListener('keydown', function (e) {
      var next = index;
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault(); openApp(item.getAttribute('data-app')); return;
      }
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') next = (index + 1) % items.length;
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') next = (index + items.length - 1) % items.length;
      else if (e.key === 'Home') next = 0;
      else if (e.key === 'End') next = items.length - 1;
      else return;
      e.preventDefault(); items[next].focus();
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      if (currentStack.length > 1) goBack();
      else if (bridge && bridge.ui) bridge.ui.close();
    }
  });
  var originalUpdate = updateHomeScreen;
  updateHomeScreen = function () {
    originalUpdate();
    var badge = document.getElementById('mono-source');
    if (badge) {
      badge.textContent = dataStatus === 'ready' ? '本局档案' : dataStatus === 'error' ? '读取未就绪' : '读取中';
      badge.title = '终端 v' + (bridge && bridge.version || '未连接') + '；' + (dataStatus === 'error' ? dataError : '读取当前回复的 MVU 记录，未获知的人物资料保持空白。');
    }
  };
  updateHomeScreen();
})();

