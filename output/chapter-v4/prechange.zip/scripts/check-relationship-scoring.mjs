import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { createSchema, INITIAL_STATE, RELATIONSHIP_SCORING, supportStage, romanceStage, enforceRelationshipScores } from '../世界书规则/MVU/schema.mjs';

const require = createRequire(import.meta.url);
const { z } = require('../output/worldbook-calibration/dev/node_modules/zod');
const schema = createSchema(z), clone = structuredClone, results = [];
const relation = (overrides = {}) => ({ 关系: '本局已确认的协作对象', 态度印象: '肯定配合表现', 好感: 52, 支援度: 7, 羁绊阶段: '未建立', 变化依据: '上次共同完成巡查', ...overrides });
const state = (record = relation()) => {
  const value = clone(INITIAL_STATE);
  value.系统 = { 结构版本: 3, 开局状态: '已建档', 主角模式: '自定义角色' };
  value.玩家.姓名 = '通用测试角色';
  value.场景.当前章 = '第一章'; value.场景.阶段 = '进行中';
  if (record) value.人际.协作对象 = record;
  return value;
};
function test(name, run) { try { run(); results.push({ name, passed: true }); } catch (error) { results.push({ name, passed: false, error: error.message }); } }
function update(record, changes) {
  const previous = { stat_data: state(record) }, variables = clone(previous);
  Object.assign(variables.stat_data.人际.协作对象, { 变化依据: '本轮按分工救出被困者，双方均参与撤离' }, changes);
  const notices = enforceRelationshipScores(variables, previous);
  return { previous, variables, actual: variables.stat_data.人际.协作对象, notices };
}

test('配置采用用户最终确认的三档支援范围', () => {
  assert.deepEqual([RELATIONSHIP_SCORING.support.ordinaryMin, RELATIONSHIP_SCORING.support.ordinaryMax, RELATIONSHIP_SCORING.support.mediumMin, RELATIONSHIP_SCORING.support.mediumMax, RELATIONSHIP_SCORING.support.majorMin, RELATIONSHIP_SCORING.support.majorMax], [1, 5, 6, 10, 10, 15]);
  assert.deepEqual(RELATIONSHIP_SCORING.affection, { min: 0, max: 1000, initial: 50, ordinaryMax: 2, majorMax: 5 });
});
test('好感扩展到 1000，1001 与负值仍被字段约束拒绝', () => {
  for (const value of [0, 100, 101, 999, 1000]) {
    assert.equal(schema.parse(state(relation({ 好感: value }))).人际.协作对象.好感, value);
  }
  for (const value of [-1, 1001]) assert.equal(schema.safeParse(state(relation({ 好感: value }))).success, false);
});
test('提高上限不放大旧好感数字，也不将旧 null 初始化成 50', () => {
  for (const value of [null, 0, 50, 52, 100]) {
    const input = state(relation({ 好感: value })), before = clone(input);
    assert.equal(schema.parse(input).人际.协作对象.好感, value);
    assert.deepEqual(input, before);
    const variables = { stat_data: clone(input) };
    assert.deepEqual(enforceRelationshipScores(variables, { stat_data: input }), []);
    assert.equal(variables.stat_data.人际.协作对象.好感, value);
  }
});
test('扩展后的高分仍按每轮 ±5 限制，不能按新上限放大增减', () => {
  for (const [before, after] of [[995, 1000], [1000, 995]]) {
    const result = update(relation({ 好感: before }), { 好感: after });
    assert.equal(result.actual.好感, after); assert.deepEqual(result.notices, []);
  }
  for (const [before, after] of [[500, 506], [500, 494], [998, 1001]]) {
    const result = update(relation({ 好感: before }), { 好感: after });
    assert.equal(result.actual.好感, before);
    assert.ok(result.notices.some(item => item.path.endsWith('/好感')));
  }
});
test('女性恋爱阶段按已确认好感派生，覆盖每个阈值前后', () => {
  assert.equal(RELATIONSHIP_SCORING.version, 'R06-关系第二版');
  for (const [value, expected] of [[0, '路人'], [199, '路人'], [200, '在意'], [499, '在意'], [500, '暧昧'], [799, '暧昧'], [800, '交往'], [999, '交往'], [1000, '生死相随']]) {
    const record = relation({ 性别: '女性', 好感: value });
    assert.equal(romanceStage(record), expected);
    assert.equal(schema.parse(state({ ...record, 恋爱阶段: '生死相随' })).人际.协作对象.恋爱阶段, expected);
    assert.equal(Object.hasOwn(record, '恋爱阶段'), false);
  }
});
test('男性与性别未知没有恋爱阶段，男女支援 C 至 S 使用同一阈值', () => {
  for (const gender of [undefined, '未知', '男性', '女性']) {
    for (const [value, expected] of [[80, 'C'], [160, 'B'], [240, 'A'], [320, 'S']]) {
      const record = relation({ 好感: 1000, 支援度: value });
      if (gender !== undefined) record.性别 = gender;
      const parsed = schema.parse(state(record)).人际.协作对象;
      assert.equal(parsed.羁绊阶段, expected);
      if (gender === '女性') assert.equal(parsed.恋爱阶段, '生死相随');
      else { assert.equal(Object.hasOwn(parsed, '恋爱阶段'), false); assert.equal(romanceStage(record), null); }
    }
  }
});
test('男性、未知性别或女性旧 null 预写恋爱阶段时明确拒绝字段路径', () => {
  for (const record of [relation({ 性别: '男性' }), relation({ 性别: '未知' }), relation(), relation({ 性别: '女性', 好感: null })]) {
    const result = schema.safeParse(state({ ...record, 恋爱阶段: '路人' }));
    assert.equal(result.success, false);
    assert.ok(result.error.issues.some(issue => issue.path.join('/') === '人际/协作对象/恋爱阶段' && issue.message.includes('不能预写')));
  }
});
test('女性旧 null 和未知性别旧数字读取时不凭空建账或猜性别', () => {
  for (const record of [relation({ 性别: '女性', 好感: null }), relation({ 好感: 999 })]) {
    const input = state(record), before = clone(input);
    const parsed = schema.parse(input).人际.协作对象;
    assert.equal(parsed.好感, record.好感);
    assert.equal(Object.hasOwn(parsed, '恋爱阶段'), false);
    assert.deepEqual(input, before);
  }
});
test('重大剧情提供全新突破依据可突破单次幅度，但仍受总范围约束', () => {
  const success = update(relation({ 性别: '女性', 好感: 100 }), { 好感: 800, 好感突破依据: '面对实际牺牲后双方明确确认关系发生转变' });
  assert.equal(success.actual.好感, 800); assert.equal(success.actual.恋爱阶段, '交往'); assert.deepEqual(success.notices, []);
  const full = update(relation({ 性别: '女性', 好感: 100 }), { 好感: 1000, 好感突破依据: '本轮危机中作出并履行了共同承担生死的决定' });
  assert.equal(full.actual.好感, 1000); assert.equal(full.actual.恋爱阶段, '生死相随'); assert.deepEqual(full.notices, []);
  const invalid = update(relation({ 性别: '女性', 好感: 998 }), { 好感: 1001, 好感突破依据: '即使有新重大剧情也不能越过总上限' });
  assert.equal(invalid.actual.好感, 998); assert.equal(invalid.actual.恋爱阶段, '交往');
});
test('重大剧情突破可表现好感下降，未擅自添加只涨不跌或额外幅度上限', () => {
  const result = update(relation({ 性别: '女性', 好感: 900 }), { 好感: 100, 好感突破依据: '本局重大背叛被当面证实，双方关系实际破裂' });
  assert.equal(result.actual.好感, 100); assert.equal(result.actual.恋爱阶段, '路人'); assert.deepEqual(result.notices, []);
});
test('沿用同一突破理由不能永久解锁，普通事件仍只允许原增幅', () => {
  const record = relation({ 性别: '女性', 好感: 500, 好感突破依据: '此前危机共同承担后果' });
  for (const reason of ['此前危机共同承担后果', ' 此前危机共同承担后果 ']) {
    const result = update(record, { 好感: 800, 好感突破依据: reason });
    assert.equal(result.actual.好感, 500); assert.equal(result.actual.恋爱阶段, '暧昧');
    assert.ok(result.notices.some(item => item.path.endsWith('/好感')));
  }
  const ordinary = update(record, { 好感: 505 });
  assert.equal(ordinary.actual.好感, 505); assert.deepEqual(ordinary.notices, []);
  const blank = update(record, { 好感: 510, 好感突破依据: '' });
  assert.equal(blank.actual.好感, 500); assert.equal(blank.actual.好感突破依据, record.好感突破依据);
});
test('未成功突破时不能清空或预改突破依据，再复用旧理由仍被拒', () => {
  const record = relation({ 性别: '女性', 好感: 500, 好感突破依据: '上次已使用的重大剧情' });
  for (const reason of ['', '打算预先写入但未发生计分的理由']) {
    const first = update(record, { 好感突破依据: reason });
    assert.equal(first.actual.好感突破依据, record.好感突破依据);
    const reused = update(first.actual, { 好感: 800, 好感突破依据: record.好感突破依据 });
    assert.equal(reused.actual.好感, 500);
  }
});
test('未使用的空突破依据是合法元信息，新旧记录均不制造恢复通知', () => {
  for (const empty of ['', '  \t\n ']) {
    const previous = { stat_data: state(null) }, variables = clone(previous);
    variables.stat_data.人际.新人物 = relation({ 好感: 50, 支援度: 0, 好感突破依据: empty, 变化依据: '本局首次实际交流，确认日常安排' });
    variables.stat_data = schema.parse(variables.stat_data);
    assert.deepEqual(enforceRelationshipScores(variables, previous), []);
    assert.equal(variables.stat_data.人际.新人物.好感突破依据, empty);
    const existing = update(relation(), { 好感突破依据: empty });
    assert.deepEqual(existing.notices, []); assert.equal(existing.actual.好感突破依据, empty);
    const used = update(relation({ 好感突破依据: '先前成功突破的事件' }), { 好感突破依据: empty });
    assert.equal(used.actual.好感突破依据, '先前成功突破的事件');
    assert.ok(used.notices.some(item => item.path.endsWith('/好感突破依据')));
  }
});
test('突破仍需要新的计分事件，失败不消费理由，修正后可重试', () => {
  const record = relation({ 性别: '女性', 好感: 100, 好感突破依据: '更早已计分的事件' });
  for (const evidence of ['', record.变化依据]) {
    const rejected = update(record, { 好感: 800, 好感突破依据: '本轮新的关系转折', 变化依据: evidence });
    assert.equal(rejected.actual.好感, 100); assert.equal(rejected.actual.好感突破依据, record.好感突破依据);
    assert.equal(rejected.actual.变化依据, record.变化依据);
    const retried = update(rejected.actual, { 好感: 800, 好感突破依据: '本轮新的关系转折', 变化依据: '本轮发生的新事件，已确认具体后果' });
    assert.equal(retried.actual.好感, 800); assert.deepEqual(retried.notices, []);
  }
});
test('跨阈值写入失败后恋爱阶段按恢复的分值重新派生', () => {
  const previous = { stat_data: schema.parse(state(relation({ 性别: '女性', 好感: 198 }))) };
  const variables = clone(previous);
  Object.assign(variables.stat_data.人际.协作对象, { 好感: 800, 变化依据: '普通交谈被模型误写为高幅度' });
  variables.stat_data = schema.parse(variables.stat_data);
  assert.equal(variables.stat_data.人际.协作对象.恋爱阶段, '交往');
  enforceRelationshipScores(variables, previous);
  assert.equal(variables.stat_data.人际.协作对象.好感, 198);
  assert.equal(variables.stat_data.人际.协作对象.恋爱阶段, '路人');
});
test('模型不能将已确认男性改为女性解锁路线，其他合法计分仍保留', () => {
  const previous = { stat_data: state(relation({ 性别: '男性', 好感: 198 })) }, variables = clone(previous);
  Object.assign(variables.stat_data.人际.协作对象, { 性别: '女性', 好感: 200, 支援度: 10, 变化依据: '本轮切磋中完成实际配合' });
  variables.stat_data = schema.parse(variables.stat_data);
  assert.equal(variables.stat_data.人际.协作对象.恋爱阶段, '在意');
  const notices = enforceRelationshipScores(variables, previous), record = variables.stat_data.人际.协作对象;
  assert.equal(record.性别, '男性'); assert.equal(record.好感, 200); assert.equal(record.支援度, 10);
  assert.equal(Object.hasOwn(record, '恋爱阶段'), false);
  assert.ok(notices.some(item => item.path.endsWith('/性别')));
});
test('已确认性别不能改另一性别或删除，未知到明确性别允许', () => {
  for (const [before, attempted] of [['男性', '未知'], ['女性', '男性'], ['女性', undefined]]) {
    const result = update(relation({ 性别: before }), { 性别: attempted });
    assert.equal(result.actual.性别, before); assert.ok(result.notices.some(item => item.path.endsWith('/性别')));
  }
  for (const gender of ['男性', '女性']) {
    const result = update(relation({ 性别: '未知' }), { 性别: gender });
    assert.equal(result.actual.性别, gender); assert.deepEqual(result.notices, []);
    assert.equal(result.actual.恋爱阶段, gender === '女性' ? '路人' : undefined);
  }
});
test('阶段修复只处理当事人，不更改框架元数据或其他记录', () => {
  const previous = { stat_data: state(relation({ 性别: '男性', 好感: 198 })) }, variables = clone(previous);
  variables.stat_data.$internal = { display_data: clone(previous.stat_data), delta_data: {} };
  const internal = variables.stat_data.$internal;
  variables.stat_data.人际.旁人 = relation({ 性别: '女性', 好感: null });
  variables.stat_data.人际.协作对象.恋爱阶段 = '生死相随';
  const notices = enforceRelationshipScores(variables, previous);
  assert.equal(Object.hasOwn(variables.stat_data.人际.协作对象, '恋爱阶段'), false);
  assert.equal(variables.stat_data.人际.旁人.好感, null);
  assert.strictEqual(variables.stat_data.$internal, internal);
  assert.ok(notices.some(item => item.path.endsWith('/恋爱阶段')));
});
test('各段边界由数字派生，包括 B 前后与满支援', () => {
  for (const [value, stage] of [[0, '未建立'], [79, '未建立'], [80, 'C'], [159, 'C'], [160, 'B'], [239, 'B'], [240, 'A'], [319, 'A'], [320, 'S']]) {
    assert.equal(supportStage(value), stage);
    assert.equal(schema.parse(state(relation({ 支援度: value, 羁绊阶段: 'S' }))).人际.协作对象.羁绊阶段, stage);
  }
});
test('旧 null 和缺字段保留原样，读取不建账不折算旧 C', () => {
  for (const support of ['missing', null]) {
    const record = relation({ 好感: null, 羁绊阶段: 'C' });
    if (support === 'missing') delete record.支援度; else record.支援度 = null;
    const input = state(record), frozenBefore = clone(input);
    assert.deepEqual(schema.parse(input).人际.协作对象, record); assert.deepEqual(input, frozenBefore);
    assert.equal(supportStage(record.支援度), '未定');
  }
});
test('非法支援值拒绝，不能把小数或字符串转成整数', () => {
  for (const value of [-1, 321, 12.5, '80', true, {}, []]) assert.equal(schema.safeParse(state(relation({ 支援度: value }))).success, false, JSON.stringify(value));
});
test('派生阶段不修改输入或 MVU 框架快照', () => {
  const input = state(relation({ 支援度: 80, 羁绊阶段: '未建立' }));
  input.$internal = { display_data: clone(input), delta_data: {} };
  const before = clone(input), output = schema.parse(input);
  assert.equal(output.人际.协作对象.羁绊阶段, 'C'); assert.deepEqual(input, before); assert.strictEqual(output.$internal, input.$internal);
});
test('新关系从好感 50 / 支援 0 建账不是越限', () => {
  const previous = { stat_data: state(null) }, variables = clone(previous);
  variables.stat_data.人际.新人物 = relation({ 好感: 50, 支援度: 0, 变化依据: '本局初次交谈，双方确认日后的任教安排' });
  assert.deepEqual(enforceRelationshipScores(variables, previous), []);
  assert.equal(variables.stat_data.人际.新人物.好感, 50); assert.equal(variables.stat_data.人际.新人物.支援度, 0);
});
test('新关系只有认识事实时保留空支援账，下轮真实协作可以累计', () => {
  const previous = { stat_data: state(null) }, first = clone(previous);
  first.stat_data.人际.新人物 = relation({ 好感: null, 支援度: 0, 羁绊阶段: '未建立', 变化依据: '' });
  first.stat_data = schema.parse(first.stat_data);
  assert.deepEqual(enforceRelationshipScores(first, previous), []);
  assert.equal(first.stat_data.人际.新人物.支援度, 0);
  assert.equal(first.stat_data.人际.新人物.好感, null);
  const second = clone(first);
  Object.assign(second.stat_data.人际.新人物, { 支援度: 3, 变化依据: '本轮共同检查巡查路线，解决交接遗漏并按时完成巡查' });
  assert.deepEqual(enforceRelationshipScores(second, first), []);
  assert.equal(second.stat_data.人际.新人物.支援度, 3);
  assert.equal(second.stat_data.人际.新人物.羁绊阶段, '未建立');
});
test('空账豁免不允许新关系无依据直接得到协作分', () => {
  const previous = { stat_data: state(null) }, after = clone(previous);
  after.stat_data.人际.新人物 = relation({ 好感: null, 支援度: 3, 变化依据: '' });
  const notices = enforceRelationshipScores(after, previous);
  assert.ok(notices.some(item => item.path === '/人际/新人物/支援度'));
  assert.equal(after.stat_data.人际.新人物.支援度, undefined);
});
test('旧好感 null 下一次有效交往允许按 50 起点只记本次', () => {
  const { actual, notices } = update(relation({ 好感: null }), { 好感: 51 });
  assert.deepEqual(notices, []); assert.equal(actual.好感, 51);
});
test('旧好感 null 不能追补到 80，其他真实印象仍保留', () => {
  const { actual, notices } = update(relation({ 好感: null }), { 好感: 80, 态度印象: '本轮肯定了处理问题的方法' });
  assert.equal(actual.好感, null); assert.equal(actual.态度印象, '本轮肯定了处理问题的方法'); assert.equal(notices[0].path, '/人际/协作对象/好感');
});
test('全部计分失败后恢复旧依据，同事件改为合法数值可以重试', () => {
  const previous = { stat_data: state(relation({ 好感: null, 变化依据: '事件 A：先前完成交接' })) };
  const failed = clone(previous);
  Object.assign(failed.stat_data.人际.协作对象, { 好感: 80, 变化依据: '事件 B：本轮履约获得轻微认可', 态度印象: '本轮肯定了履约表现', 已知资料: { 身份: '本次介绍的负责人' } });
  const notices = enforceRelationshipScores(failed, previous);
  assert.equal(failed.stat_data.人际.协作对象.好感, null);
  assert.equal(failed.stat_data.人际.协作对象.变化依据, '事件 A：先前完成交接');
  assert.equal(failed.stat_data.人际.协作对象.态度印象, '本轮肯定了履约表现');
  assert.equal(failed.stat_data.人际.协作对象.已知资料.身份, '本次介绍的负责人');
  assert.ok(notices.some(item => item.path === '/人际/协作对象/变化依据' && item.message.includes('重试')));
  const retry = clone(failed);
  Object.assign(retry.stat_data.人际.协作对象, { 好感: 51, 变化依据: '事件 B：本轮履约获得轻微认可' });
  assert.deepEqual(enforceRelationshipScores(retry, failed), []);
  assert.equal(retry.stat_data.人际.协作对象.好感, 51);
  assert.equal(retry.stat_data.人际.协作对象.变化依据, '事件 B：本轮履约获得轻微认可');
});
test('混合结果有一项计分成功时保留本轮依据，不能重刷已成功项', () => {
  const previous = { stat_data: state(relation({ 好感: null })) }, first = clone(previous);
  Object.assign(first.stat_data.人际.协作对象, { 好感: 80, 支援度: 10, 变化依据: '事件 B：完成新的协作目标' });
  enforceRelationshipScores(first, previous);
  assert.equal(first.stat_data.人际.协作对象.好感, null);
  assert.equal(first.stat_data.人际.协作对象.支援度, 10);
  assert.equal(first.stat_data.人际.协作对象.变化依据, '事件 B：完成新的协作目标');
  const repeated = clone(first);
  Object.assign(repeated.stat_data.人际.协作对象, { 好感: 51, 支援度: 13 });
  const notices = enforceRelationshipScores(repeated, first);
  assert.equal(repeated.stat_data.人际.协作对象.好感, null);
  assert.equal(repeated.stat_data.人际.协作对象.支援度, 10);
  assert.ok(notices.some(item => item.message.includes('重复')));
});
test('旧好感 null 可以独立建账，旧支援待核定被拒不牵连好感或旧阶段', () => {
  const { actual, notices } = update(relation({ 好感: null, 支援度: null, 羁绊阶段: 'C' }), { 好感: 51, 支援度: 3, 羁绊阶段: '未建立' });
  assert.equal(actual.好感, 51);
  assert.equal(actual.支援度, null);
  assert.equal(actual.羁绊阶段, 'C');
  assert.equal(actual.变化依据, '本轮按分工救出被困者，双方均参与撤离');
  assert.ok(notices.some(item => item.path === '/人际/协作对象/支援度'));
  assert.equal(notices.some(item => item.path === '/人际/协作对象/好感'), false);
});
test('旧支援未知时模型不能自行从 0 清掉旧 C', () => {
  for (const initial of ['missing', null]) {
    const record = relation({ 羁绊阶段: 'C' });
    if (initial === 'missing') delete record.支援度; else record.支援度 = null;
    const { actual, notices } = update(record, { 支援度: 2, 羁绊阶段: '未建立' });
    assert.equal(actual.支援度, initial === 'missing' ? undefined : null); assert.equal(actual.羁绊阶段, 'C'); assert.ok(notices.some(n => n.message.includes('待核定')));
  }
});
test('玩家已有核定数字后允许本次累计，并跨边界派生阶段', () => {
  const { actual, notices } = update(relation({ 支援度: 78 }), { 支援度: 81, 羁绊阶段: 'S' });
  assert.deepEqual(notices, []); assert.equal(actual.羁绊阶段, 'C');
});
test('整轮累计 +15 可通过，+16 拒绝，即使拆分多条补丁', () => {
  assert.equal(update(relation(), { 支援度: 22 }).actual.支援度, 22);
  const { actual, notices } = update(relation(), { 支援度: 23 });
  assert.equal(actual.支援度, 7); assert.equal(notices.filter(item => item.path.endsWith('/支援度')).length, 1);
});
test('拒绝好感越限只恢复该数值，合法支援与另一人物不受影响', () => {
  const previous = { stat_data: state() }, variables = clone(previous);
  variables.stat_data.场景.地点 = '共同训练场';
  variables.stat_data.人际.协作对象 = relation({ 好感: 60, 支援度: 10, 态度印象: '仍有分歧但认可分工', 变化依据: '本轮共同解决巡查交接遗漏' });
  variables.stat_data.人际.另一人物 = relation({ 好感: 50, 支援度: 0, 变化依据: '初次认识的共同工作人员' });
  const notices = enforceRelationshipScores(variables, previous);
  assert.equal(variables.stat_data.人际.协作对象.好感, 52); assert.equal(variables.stat_data.人际.协作对象.支援度, 10);
  assert.equal(variables.stat_data.人际.另一人物.好感, 50); assert.equal(variables.stat_data.场景.地点, '共同训练场');
  assert.equal(variables.stat_data.人际.协作对象.态度印象, '仍有分歧但认可分工'); assert.equal(notices.length, 1);
});
test('与上次完全相同的计分依据不再加减分', () => {
  const { actual, notices } = update(relation(), { 好感: 53, 支援度: 8, 变化依据: ' 上次共同完成巡查 ' });
  assert.equal(actual.好感, 52); assert.equal(actual.支援度, 7); assert.equal(notices.filter(item => /\/(好感|支援度)$/.test(item.path)).length, 2);
});
test('缺变化依据拒绝计分，不把空标签变成默认分数', () => {
  const { actual, notices } = update(relation(), { 好感: 53, 支援度: 8, 变化依据: '' });
  assert.equal(actual.好感, 52); assert.equal(actual.支援度, 7); assert.equal(notices.filter(item => /\/(好感|支援度)$/.test(item.path)).length, 2);
});
test('模型不能清空已计分数字或单独升未核定字母', () => {
  const erased = update(relation(), { 好感: null, 支援度: null });
  assert.equal(erased.actual.好感, 52); assert.equal(erased.actual.支援度, 7);
  const record = relation({ 支援度: null, 羁绊阶段: 'C' });
  assert.equal(update(record, { 羁绊阶段: 'S' }).actual.羁绊阶段, 'C');
});
test('支援满值保持 S，但关系不会被改成恋爱', () => {
  const { actual, notices } = update(relation({ 支援度: 310, 羁绊阶段: 'A', 关系: '任教班级学生' }), { 支援度: 320 });
  assert.deepEqual(notices, []); assert.equal(actual.羁绊阶段, 'S'); assert.equal(actual.关系, '任教班级学生');
});
test('安装后的 guard 对计分单字段还原并报告具体路径', () => {
  const hooks = new Map(), warnings = [], W = { addEventListener() {} };
  W.parent = W;
  const realm = vm.createContext({ window: W, structuredClone, console: { warn: text => warnings.push(text) },
    Mvu: { events: { VARIABLE_UPDATE_ENDED: 'end' } }, eventOn: (name, cb) => { hooks.set(name, cb); return { stop() {} }; },
    cloneState: clone, enforceStateOwnership: () => [], enforceRelationshipScores, RELATIONSHIP_SCORING });
  vm.runInContext(fs.readFileSync(new URL('./rakudai-mvu-guard.js', import.meta.url), 'utf8') + '\ninstallRakudaiMvuGuard({safeParse(){throw new Error("关系检查不应触发整根回滚验证")}});', realm);
  const previous = { stat_data: state() }, variables = clone(previous);
  Object.assign(variables.stat_data.人际.协作对象, { 好感: 70, 支援度: 10, 变化依据: '本轮完成新的协作目标', 态度印象: '保留本轮印象' });
  variables.stat_data.场景.地点 = '保留本轮地点';
  hooks.get('end')(variables, previous);
  assert.equal(variables.stat_data.人际.协作对象.好感, 52); assert.equal(variables.stat_data.人际.协作对象.支援度, 10);
  assert.equal(variables.stat_data.场景.地点, '保留本轮地点'); assert.ok(warnings.some(text => text.includes('/人际/协作对象/好感')));
});
test('可导入约束 JSON 同时包含计分配置、派生函数和独立数值检查', () => {
  const script = JSON.parse(fs.readFileSync(new URL('../世界书规则/MVU/落第骑士-MVU-v3字段约束.json', import.meta.url), 'utf8'));
  const realm = vm.createContext({ $() {}, structuredClone });
  new vm.Script(script.content).runInContext(realm);
  assert.equal(vm.runInContext('RELATIONSHIP_SCORING.support.majorMax', realm), 15);
  assert.equal(vm.runInContext('RELATIONSHIP_SCORING.affection.max', realm), 1000);
  assert.equal(vm.runInContext('RELATIONSHIP_SCORING.version', realm), 'R06-关系第二版');
  assert.equal(typeof realm.enforceRelationshipScores, 'function');
  assert.equal(typeof realm.romanceStage, 'function');
  assert.equal(realm.createSchema(z).parse(state(relation({ 支援度: 160, 羁绊阶段: '未建立' }))).人际.协作对象.羁绊阶段, 'B');
  assert.equal(realm.createSchema(z).parse(state(relation({ 性别: '女性', 好感: 800 }))).人际.协作对象.恋爱阶段, '交往');
});

const report = { passed: results.filter(r => r.passed).length, total: results.length, runtime: '离线 schema 与 MVU 结束事件模拟，未连接真实酒馆', results };
console.log(JSON.stringify(report, null, 2));
if (report.passed !== report.total) process.exitCode = 1;
